package com.base.commom.listener;

/**
 * MagicIndicator 标题点击回调
 */
public interface IndicatorClickListener {
    void onClick(int index);
}
