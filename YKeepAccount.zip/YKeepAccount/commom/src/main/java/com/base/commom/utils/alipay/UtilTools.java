package com.base.commom.utils.alipay;


import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class UtilTools {
    private static String TAG = "TAG--UtilTools";

    private static Pattern mPattern;
    private static Matcher mMatcher;




    /**
     * double保留两位数字
     *
     * @return
     */
    public static double Double2(Double d) {
        if (d != null) {
            if (d == 0) {
                return 0.00;
            }
            DecimalFormat df = new DecimalFormat("#0.00");
            return str2Double(df.format(d));
        }
        return 0.00;
    }


    public static double str2Double(String str) {

        return Double.parseDouble(str) * 100 * 0.01;
    }



}
