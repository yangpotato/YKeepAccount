package com.base.commom.utils.wxpay;


import com.base.commom.BaseConstants;

/**
 * Created by zhengkq on 2017/1/17. 微信信息
 */

public class ParameterConfig {
    /**
     * 微信appid
     */
    public static final String WX_APP_ID = "wx085023c5253df931";
    // 商户号
    public static final String WX_MCH_ID = "1574223561";
    // API密钥，在商户平台设置
    public static final String WX_API_KEY = "EGjZJ7CTQuB1P6kKbXdixc4Zcbnhi3f4";
    // AppSecret
    public static final String WX_API_APPSECRET = "bfd7d21aa614d01259c1ca2d34ff0bc3";
    //回调地址
    public static final String WX_notifyUrl = BaseConstants.BASE_URL + "order/notify/wxpay";
}

