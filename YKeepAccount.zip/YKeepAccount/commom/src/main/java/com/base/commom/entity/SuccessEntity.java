package com.base.commom.entity;

public class SuccessEntity {
    private boolean issuccess;
    public boolean is_success;

    public boolean isIssuccess() {
        return issuccess;
    }

    public void setIssuccess(boolean issuccess) {
        this.issuccess = issuccess;
    }
}
