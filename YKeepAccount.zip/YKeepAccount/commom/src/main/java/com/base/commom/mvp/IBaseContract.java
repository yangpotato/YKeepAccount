package com.base.commom.mvp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.widget.ProgressBar;

import com.lxj.xpopup.core.BasePopupView;

import java.util.List;
import java.util.Map;

/**
 * @author 1one
 * @date 2019/8/24.
 */
public interface IBaseContract {

    interface View {

        ProgressDialog getProgressDialog();

        void initProgressDialog();

        void showLoading();

        void showNormal();

        void showError();

        void showLoginPage();

        void showLoadingDialog(String msg);

        void dismissLoadingDialog();

        void showMessage(String msg);

        BasePopupView getLoadingDialog();

        void setList(List list, int count, boolean isLoadMore);

        void onGiftNotEnough(int type, Map<String, Object> map);

        //TODO(3.12 添加)
        void buyIntegralGoodsSuccess();

        //TODO(3.12 添加)
        void giveIntegralGoodsSuccess();

        void showIntegralNotEnough();

    }

    interface Presenter<V extends View> {

        void onSaveInstanceState(Bundle outState);

        void onRestoreInstanceState(Bundle outState);

        void attachView(@NonNull V view);

        void detachView();

        /**
         * view initialized, you can init view data
         */
        void onViewInitialized();

        @Nullable
        Context getContext();

        //TODO(3.12 添加)
        void buyIntegralGoods(int type, Map<String, Object> map);

        /**
         * type : 区分赠送人还是任务 0:人  1：任务
         */
        //TODO(3.12 添加)
        void giveIntegralGoods(int type, Map<String, Object> map);
    }
}
