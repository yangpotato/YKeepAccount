package com.base.commom.entity;

public class SuccessIntEntity {
    private int issuccess;
    public int is_success;



    public int getIssuccess() {
        return issuccess;
    }

    public void setIssuccess(int issuccess) {
        this.issuccess = issuccess;
    }
}
