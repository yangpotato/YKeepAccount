package com.base.commom.listener;

public interface OnCommonRefreshLoadMoreListener {
    void onRefresh();

    void onLoadMore();
}
