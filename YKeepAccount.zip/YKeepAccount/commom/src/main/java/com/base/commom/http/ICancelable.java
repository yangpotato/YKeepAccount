package com.base.commom.http;

/**
 * @author 1one
 * @date 2019/8/27.
 */
public interface ICancelable {

    void cancel();

}
