package com.base.commom.listener;

import android.view.View;

public interface OnSimpleClickListener {
    void click(View view);
}
